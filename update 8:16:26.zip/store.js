// Booking storage backed by Redis (provisioned via the Vercel Marketplace —
// this project uses the "Redis" / Redis Cloud integration, which hands back
// a single standard connection string in REDIS_URL, not a REST URL+token
// pair, so this uses ioredis rather than an HTTP-based client).
//
// Everything lives under two keys:
//   - "all_bookings"   -> JSON array of { id, startAt, endAt, status, expiresAt? }
//   - "blocked_ranges" -> JSON array of { id, start, end, reason }
//
// This is intentionally simple (single JSON blob per key, not per-date
// buckets) so a booking that starts late at night and runs past midnight
// is never split across two records. A short-lived lock serializes writes
// so two people checking out at the same moment can't both grab the same
// slot.

const IORedis = require('ioredis');
const { DateTime } = require('luxon');

const redisUrl =
  process.env.REDIS_URL ||
  process.env.KV_URL ||
  process.env.KV_REST_API_URL ||
  process.env.UPSTASH_REDIS_REST_URL;

// A single client is created once per warm serverless instance and reused
// across requests (the standard pattern for TCP-based Redis clients on
// Vercel) rather than opening a new connection per request.
const client = new IORedis(redisUrl, {
  maxRetriesPerRequest: 3,
  connectTimeout: 5000,
  retryStrategy(times) {
    if (times > 3) return null;
    return Math.min(times * 200, 1000);
  },
});
client.on('error', (err) => {
  console.error('Redis client error:', err.message);
});

// Thin get/set/del wrapper matching the interface the rest of this file
// already uses, so the storage logic below didn't need to change — only
// how we talk to Redis did.
const kv = {
  async get(key) {
    const raw = await client.get(key);
    if (raw === null || raw === undefined) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  },
  async set(key, value, opts) {
    const payload = typeof value === 'string' ? value : JSON.stringify(value);
    const args = [key, payload];
    if (opts && opts.ex) args.push('EX', opts.ex);
    if (opts && opts.nx) args.push('NX');
    return client.set(...args); // 'OK', or null when NX blocks the write
  },
  async del(key) {
    return client.del(key);
  },
};

const VENUE_TIMEZONE = 'America/New_York';
const SLOT_INTERVAL_MINUTES = 45;
const MINUTES_PER_DAY = 24 * 60;

const BOOKINGS_KEY = 'all_bookings';
const BLOCKED_KEY = 'blocked_ranges';
const LOCK_KEY = 'lock:all_bookings';

function overlaps(aStart, aEnd, bStart, bEnd) {
  return aStart < bEnd && bStart < aEnd;
}

async function withLock(fn) {
  const lockValue = `${Date.now()}-${Math.random()}`;
  let acquired = false;
  for (let i = 0; i < 30 && !acquired; i++) {
    acquired = await kv.set(LOCK_KEY, lockValue, { nx: true, ex: 10 });
    if (!acquired) {
      await new Promise((resolve) => setTimeout(resolve, 150));
    }
  }
  if (!acquired) {
    throw new Error('Could not get a lock on the booking calendar, please try again');
  }
  try {
    return await fn();
  } finally {
    const current = await kv.get(LOCK_KEY);
    if (current === lockValue) {
      await kv.del(LOCK_KEY);
    }
  }
}

async function getAllBookings() {
  return (await kv.get(BOOKINGS_KEY)) || [];
}

async function getBlockedRanges() {
  return (await kv.get(BLOCKED_KEY)) || [];
}

function isActive(booking, now) {
  if (booking.status === 'paid') return true;
  if (booking.status === 'pending') return new Date(booking.expiresAt) > now;
  return false;
}

// Returns { busy, blocked } as arrays of { start: Date, end: Date }
async function loadActiveRanges(now) {
  const [bookings, blocked] = await Promise.all([getAllBookings(), getBlockedRanges()]);
  const busy = bookings
    .filter((b) => isActive(b, now))
    .map((b) => ({ start: new Date(b.startAt), end: new Date(b.endAt) }));
  const blockedRanges = blocked.map((r) => ({ start: new Date(r.start), end: new Date(r.end) }));
  return { busy, blockedRanges };
}

function hasConflict(startAt, endAt, busy, blockedRanges) {
  return (
    busy.some((r) => overlaps(startAt, endAt, r.start, r.end)) ||
    blockedRanges.some((r) => overlaps(startAt, endAt, r.start, r.end))
  );
}

/**
 * Try to reserve a temporary hold on a slot. Returns { ok: true } if
 * successful, or { ok: false, reason } if the slot conflicts with an
 * existing booking or a blocked (maintenance) window.
 */
async function reserveHold({ id, startAt, endAt, holdMinutes = 30, meta = null }) {
  return withLock(async () => {
    const now = new Date();
    if (startAt < now) {
      return { ok: false, reason: 'past' };
    }
    const { busy, blockedRanges } = await loadActiveRanges(now);
    if (hasConflict(startAt, endAt, busy, blockedRanges)) {
      return { ok: false, reason: 'conflict' };
    }
    const bookings = await getAllBookings();
    bookings.push({
      id,
      startAt: startAt.toISOString(),
      endAt: endAt.toISOString(),
      status: 'pending',
      expiresAt: new Date(Date.now() + holdMinutes * 60000).toISOString(),
      // Booking details captured at hold time (name/email/duration), so a
      // later step (identity verification, then payment) can look them up
      // by id instead of trusting whatever the client sends at that point.
      meta,
      verificationStatus: null,
      verificationSessionId: null,
    });
    await kv.set(BOOKINGS_KEY, bookings);
    return { ok: true };
  });
}

async function getBooking(id) {
  const bookings = await getAllBookings();
  return bookings.find((b) => b.id === id) || null;
}

async function updateBooking(id, patch) {
  return withLock(async () => {
    const bookings = await getAllBookings();
    const idx = bookings.findIndex((b) => b.id === id);
    if (idx === -1) return null;
    bookings[idx] = { ...bookings[idx], ...patch };
    await kv.set(BOOKINGS_KEY, bookings);
    return bookings[idx];
  });
}

async function confirmBooking(id) {
  return withLock(async () => {
    const bookings = await getAllBookings();
    const idx = bookings.findIndex((b) => b.id === id);
    if (idx === -1) return false;
    bookings[idx].status = 'paid';
    delete bookings[idx].expiresAt;
    await kv.set(BOOKINGS_KEY, bookings);
    return true;
  });
}

async function releaseHold(id) {
  return withLock(async () => {
    const bookings = await getAllBookings();
    const filtered = bookings.filter((b) => b.id !== id);
    if (filtered.length !== bookings.length) {
      await kv.set(BOOKINGS_KEY, filtered);
    }
  });
}

/**
 * Returns the list of 45-min-apart start times for a given local date
 * (YYYY-MM-DD, in VENUE_TIMEZONE), each with an availability flag for
 * a session of the given duration starting there.
 */
async function getAvailableSlots(dateStr, durationMinutes) {
  const now = new Date();
  const dayStart = DateTime.fromISO(dateStr, { zone: VENUE_TIMEZONE }).startOf('day');
  if (!dayStart.isValid) {
    throw new Error('Invalid date');
  }
  const { busy, blockedRanges } = await loadActiveRanges(now);

  const slots = [];
  for (let m = 0; m < MINUTES_PER_DAY; m += SLOT_INTERVAL_MINUTES) {
    const startDt = dayStart.plus({ minutes: m });
    const endDt = startDt.plus({ minutes: durationMinutes });
    const startJS = startDt.toJSDate();
    const endJS = endDt.toJSDate();

    let available = startJS >= now;
    if (available) {
      available = !hasConflict(startJS, endJS, busy, blockedRanges);
    }

    slots.push({ start: startDt.toFormat('HH:mm'), available });
  }
  return slots;
}

async function addBlockedRange({ id, start, end, reason }) {
  return withLock(async () => {
    const ranges = await getBlockedRanges();
    ranges.push({ id, start, end, reason: reason || '' });
    await kv.set(BLOCKED_KEY, ranges);
    return ranges;
  });
}

async function removeBlockedRange(id) {
  return withLock(async () => {
    const ranges = await getBlockedRanges();
    const filtered = ranges.filter((r) => r.id !== id);
    await kv.set(BLOCKED_KEY, filtered);
    return filtered;
  });
}

module.exports = {
  VENUE_TIMEZONE,
  SLOT_INTERVAL_MINUTES,
  reserveHold,
  confirmBooking,
  releaseHold,
  getBooking,
  updateBooking,
  getAvailableSlots,
  getBlockedRanges,
  addBlockedRange,
  removeBlockedRange,
};
